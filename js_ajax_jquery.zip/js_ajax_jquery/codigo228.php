<?php
    // Archivo: codigo228.php
    // Conexión a la base de datos 
    $servidor = "localhost";
    $db = "js_php_mysql";   
    $usuario = "root";
    $contrasenna = "mini2019";
    // Establece conexión base de datos
    $mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
    // Establecer fecha actual
    $sql = "SELECT current_date";
    $row = $mysqli->query($sql);
    $consultaf = $row->fetch_assoc();
    $fechadelmysql = date_create($consultaf['current_date']);
    $fechadelmysql = date_format($fechadelmysql, 'd/m/Y');
    $fecha = $fechadelmysql;
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
    <!-- jQuery Datepicker -->
    <link rel="stylesheet" href="css/jqueryut.css">
    <script src="js/jqueryut1.js"></script>
    <script src="js/jqueryut2.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function(){
            // Función jQuery
            $( "#datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        });
    </script>
</head>
<body>
    <h3>Date Picker (jQuery)</h3>
    <form method="POST" action="codigo229.php">
        <label><b>Fecha</b></label>
        <input type="text" name="fecha" id="datepicker" class="datepicker" maxlength="10" readonly val-ue="<?php echo $fecha ?>"/>
        <button class="boton"><b>Enviar</b></button>
    </form>
</body>
</html>