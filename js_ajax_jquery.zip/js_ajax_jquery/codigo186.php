<!-- 
Archivo: codigo186.php
-->
<?php
    // Iniciar sesión del Usuario
    session_start();
    // Iniciar variables se sesiones
    if (!isset($_SESSION["usuario_error"])){
        $_SESSION["usuario_error"] = "No";
    }
    if (!isset($_SESSION["usuario_error_mensaje"])){
        $_SESSION["usuario_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["usuario"])){
        $_SESSION["usuario"] = "";
    }
    if (!isset($_SESSION["clave"])){
        $_SESSION["clave"] = "";
    }
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
	<!-- Mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
	<!-- Formulario -->    
    <form name="formulario_usuario" method="POST" action="codigo187.php" onsubmit="return validar_formulario_usuario()">
        <label>Usuario</label>
        <br/>
        <!-- Campo de texto Usuario -->   
    	<input type="text" name="usuario" maxlength="10" value="<?php echo $_SESSION["usuario"] ?>">
        <br/>
        <label>Clave</label>
        <br/>
        <!-- Campo de texto Clave -->   
    	<input type="password" name="clave" maxlength="10" value="<?php echo $_SESSION["clave"] ?>">
        <br/><br/>
        <!-- Botón Abrir -->   
        <input type="submit" value="Iniciar">
    </form>
    <!-- Mensaje SweetAlert -->
    <?php
		$error = $_SESSION["usuario_error"];
        $error_mensaje = $_SESSION["usuario_error_mensaje"];
        if ($error=="Si") { // Si el campo esta vacío
            $_SESSION["usuario_error"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $error_mensaje ?>',
                    html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });
            </script>

    <?php
        }
    ?>   
    <script>
    // Validar formulario usuario con javascript
    function validar_formulario_usuario() { 
        // Declarar e iniciar variable 
        var error="";
        // Buscar texto del campo usuario
        var campo_vacio = document.forms['formulario_usuario'].elements['usuario'].value; 
        // Si el campo Usuario está vacio
        if (campo_vacio == "") {
            error += '<font style="color:red">Debes escribir el Usuario</font>';
        } else {
            // Buscar texto del campo clave
            var campo_vacio = document.forms['formulario_usuario'].elements['clave'].value; 
            // Si el campo Usuario está vacio
            if (campo_vacio == "") {
                error += '<font style="color:red">Debes escribir la Clave</font>';
            } 
        }      
        // Si hay un error manda un mensaje con SweetAlert
        if (error) {
            Swal.fire({
                title: 'Mensaje',
                text: error,
                html: error,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }
        // Si error == '' entonces es verdadero       
        valor_retorno = (error == '');
        // Retorna un valor
        return valor_retorno;
    }
    </script>    
</body>
</html>