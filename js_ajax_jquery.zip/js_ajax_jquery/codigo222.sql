-- Archivo: codigo222.sql
INSERT INTO `clientes` (`id_cliente`, `nombre`, `email`, `telefono`) VALUES
(1, 'Jose', 'josegonzales9871@gmail.com', 912546524),
(2, 'Juan', 'juanrodriguez65465@gmail.com', 934654654),
(3, 'Angelina', 'angelina654456@gmail.com', 247483647);