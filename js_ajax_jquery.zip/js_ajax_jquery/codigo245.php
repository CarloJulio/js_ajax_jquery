<?php
    // Archivo: codigo245.php
    // Iniciar sesión 
	session_start();
	// Si la varible de sesiones no están definidas
	if(!isset($_SESSION['mensaje'])) {
		$_SESSION['mensaje']="";
	}	
    if(!isset($_SESSION["mensaje_enviar"])) {
		$_SESSION["mensaje_enviar"] = "";
	}	
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
	<meta charset="UTF-8">
	<!-- Mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <title> Ejercicio </title>
</head>
<body>
	<div>
	  <h3>SweetAlert</h3>	
      <!-- Formulario HTML -->
	  <form  name="mensaje" action="codigo246.php" method="POST" onsubmit="return validar()">
        <label>Mensaje:</label>
        <br/>
        <input type="text" name="mensaje" autofocus value="<?php echo $_SESSION["mensaje"] ?>">
        <br/><br/>
        <input type="submit" value="Enviar">
     </form>
    </div> 
    <!-- Mensaje SweetAlert -->
    <?php
    $mensaje_enviar = $_SESSION["mensaje_enviar"];
    if($mensaje_enviar == "Si") {
        $_SESSION["mensaje_enviar"] = "No";
    ?>
    <script>
        // Mensaje SweetAlert
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Enviar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "codigo247.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario usuario con javascript
    function validar() { 
        var errors="";
        var mensaje = document.forms['mensaje'].elements['mensaje'].value; 
        if (mensaje == "") {
            errors += '<font style="color:red">Debes escribir el Mensaje</font>';
        } 
        // Mensaje SweetAlert
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });   
            return false;  
        } 
        return true;
    }
    </script>    
</body>
</html>