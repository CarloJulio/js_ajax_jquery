<!-- 
Archivo: codigo201.php
-->
<?php
    if (isset($_GET["edad"])) {
        $edad=$_GET["edad"];
    }
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
</head>
<body>
    <a  href="codigo200.html">Volver</a>
    <br/>
    <!-- Mostrar texto -->    
    <p>Edad:<?php echo $edad ?></p>
    </form>
</body>
</html>