<!-- Archivo: codigo182.php -->
<!-- Documento HTML5 -->
<!DOCTYPE html>
<html>
<head>
   <!-- La etiqueta meta que da el formato en español -->
   <meta charset="UTF-8">
   <!-- Título en la pestaña del navegador -->
   <title> Ejercicio </title>
</head>
<body>
  <!-- Formulario -->
  <form action="Codigo182.php" onsubmit="return validar_formulario()">
    <!-- Botón del formulario -->
    <button type="submit">Abrir Archivo</button>
  </form>
  <!-- Códigos de JavaScript -->
  <script>
    function validar_formulario() {
      // Mensaje
      alert("Acción cancelado del Formulario");
      // Cancelar la acción de formulario
      return false;
    }
  </script>
</body>
</html>