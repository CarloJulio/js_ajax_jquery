<?php
    // Archivo: codigo211.php
    // Conexión a la base de datos
	$servidor = "localhost";
	$db = "js_php_mysql";   
	$usuario = "root";
	$contrasenna = "mini2019";
    $mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
    // Lista vehículo tipos
    $id_vehiculo_tipo = $_GET['c'];
	$sqlpa="SELECT id_vehiculo_tipo, tipo FROM vehiculos_tipos WHERE (id_vehiculo = $id_vehiculo_tipo) ORDER BY id_vehiculo_tipo";
    $querypa = $mysqli->query($sqlpa);
    $combobit2="<option value='0'>Seleccione</option>";
    while ($rowpa=$querypa->fetch_assoc()) { 
        $combobit2.=" <option value='".$rowpa['id_vehiculo_tipo']."'>".$rowpa['tipo']."</option>"; 
    }
    // Nueva lista vehículo tipos en la capa div id=id_vehiculo_tipo
    echo '<select>';
	echo $combobit2;
	echo '</select>';
?>