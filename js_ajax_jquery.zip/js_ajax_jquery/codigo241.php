<?php
	// Archivo: codigo241.php
	$server = "localhost";
	$user = "root";
	$pass = "mini2019";
	$bd = "js_php_mysql";
	// Se Crea la conexión
	$conexion = mysqli_connect($server, $user, $pass, $bd) 
	or die("Error en la conexion de la base de datos");
	// Se genera la consulta
	$sql = "SELECT id_cliente, nombre, email, telefono FROM clientes";
	//formato de datos utf8	
	$result = mysqli_query($conexion, $sql);
	// Creamos un array
	$clientes = array(); 
	while($row = mysqli_fetch_array($result)) 
	{ 
		$id=$row['id_cliente'];
		$nombre=$row['nombre'];
		$email=$row['email'];
		$telefono=$row['telefono'];
		// Array
		$clientes[] = array('id'=> $id, 'nombre'=> $nombre, 
		'email'=> $email, 'telefono'=> $telefono);
	}
	// Se desconecta la base de datos
	$close = mysqli_close($conexion) 
	or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
	// Creamos el JSON
	// $clientes = $clientes[];
	// Convierte los datos del arreglo $clientes[] a formato json
	$json_string = json_encode($clientes);
	echo $json_string;
?>