<?php
	// Archivo: codigo246.php
	// Iniciar sesión del mensaje
	session_start();
	// Asignar valor del campo mensaje del formulario
	$_SESSION["mensaje"] = $_POST["mensaje"];
	// Variables de sesiones 
	$_SESSION["mensaje_enviar"] = "Si";
	$_SESSION["mensaje_recibido"] = "Si";
	echo "<script>location.href = 'codigo245.php'</script>";
?>