<!-- 
Archivo: codigo203.php
-->
<?php
    // Si está definida la variable $_GET["fecha"]
    if (isset($_GET["fecha"])) {
        // Formato fecha en inglés
        $fecha1 = $_GET["fecha"];
        // Formato fecha en español
        $fecha2 = date_create($fecha1);
        $fecha3 = date_format($fecha2,'d-m-Y');
    }
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
   <!-- La etiqueta meta que da el formato en español -->
   <meta charset="UTF-8">
</head>
<body>
    <a  href="codigo202.html">Volver</a>
    <br/>
    <!-- Mostrar texto -->    
    <p>Fecha:<?php echo $fecha3 ?></p>
    </form>
</body>
</html>