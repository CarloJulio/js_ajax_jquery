-- Archivo: codigo212.sql
CREATE TABLE `vehiculos_tipos` (
  `id_vehiculo_tipo` int(1) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(30) CHARACTER SET utf8 NOT NULL,
  `id_vehiculo` int(11) NOT NULL,
  PRIMARY KEY (`id_vehiculo_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;