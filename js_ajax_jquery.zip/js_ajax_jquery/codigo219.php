<!-- Archivo: codigo219.php --> 
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
    <script>
        // Función AJAX
        function validar(){
            // Declarar e iniciar variable 
            var error="";
            // Buscar texto del campo usuario
            var usuario = document.getElementById('usuario').value; 
            // Si el campo Usuario está vacio
            if (usuario == "") {
                error += '<font style="color:red">Debes escribir el Usuario</font>';
                document.getElementById('id_mensaje').innerHTML = error;
                return;
            } 
            // Buscar texto del campo clave
            var clave = document.getElementById('clave').value; 
            // Si el campo Usuario está vacio
            if (clave == "") {
                error += '<font style="color:red">Debes escribir la Clave</font>';
                document.getElementById('id_mensaje').innerHTML = error;
                return;
            } 
            // Compactible con diferentes navegadores
            var xmlhttp; 
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // Capa div para el AJAX
                    document.getElementById("id_principal").innerHTML=xmlhttp.responseText;
                }
            }
            // Abrir archivo con el número de la imagen y ejecutar el AJAX
            xmlhttp.open("GET","codigo220.php?usuario="+usuario+"&clave="+clave,true);
            xmlhttp.send();
        }
    </script>
</head>
<body>
    <div id="id_principal">    
    <h1>Usuario</h1>  
    <!-- Campo de texto Usuario -->  
    <label>Usuario</label> 
    <br/>
    <input onclick="borrar_mensaje()" type="text" id="usuario" maxlength="20">
    <br/>
    <!-- Campo de texto Clave -->  
    <label>Clave</label> 
    <br/>    
    <input onclick="borrar_mensaje()" type="password" id="clave" maxlength="20">
    <br/><br/>
    <!-- Llama a la función AJAX desde un botón -->  
    <button onclick="validar()"><b>Ingresar</b></button>
    <!-- Mensaje -->  
    <div id="id_mensaje"></div>
    <script>
        function borrar_mensaje(){
            document.getElementById('id_mensaje').innerHTML = "";
        }   
    </script>   
    </div 
</body>
</html>