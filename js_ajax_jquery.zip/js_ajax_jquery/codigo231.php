<?php
// Archivo: Codigo231_jquery_enviar_datos.php
// Conexión a la base de datos aprende_javascript
$servidor = "localhost";
$db = "js_php_mysql";   
$usuario = "root";
$contrasenna = "mini2019";
// Establece conexión base de datos
$mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
// Los valores del input email y el input mensaje
$email = $_POST['email'];
$mensaje = $_POST['mensaje'];
// Guardar nuevo Mensaje	
$sql="INSERT INTO mensajes (email, mensaje) ";
$sql.="VALUES ('$email','$mensaje')";
$query=$mysqli->query($sql);
// Capa div id_email_1 para el AJAX, introduce el mensaje
echo '<font style="color:green">Mensaje enviado con éxito</font>';
?>