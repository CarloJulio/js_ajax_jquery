<!-- Archivo: codigo230.php -->
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
    <!-- Librería jQuery -->
    <script src="js/jquery-1.10.1.min.js"></script>
</head>
<body>
    <h1>Mensaje (jQuery)</h1>
    <div id="mensaje2">
        <form method="POST" action="return false" onsubmit="return false">
        <label>Email</label>
        <br/>
        <!-- Campo de texto Email -->   
        <input onclick="borrar_mensaje()" type="text" id="id_email_2" maxlength="30" >
        <br/>
        <label>Mensaje</label>
        <br/>
        <!-- Campo de texto Mensaje -->   
        <Textarea ROWS="3" COLS="30"type="text" onclick="borrar_mensaje()" id="id_mensaje" maxlength="150"></TEXTAREA>
        <br/>
        <!-- Llama a la función en JavaScript desde un botón -->  
        <button onclick="enviar();"><b>Enviar</b></button>
        <div id="mensaje1"></div>
        </form>
    </div>
    <script>
        // Enviar datos con JavaScript y jQuery     
        function enviar()
        {
            // Declarar e iniciar variable 
            var error="";
            // Buscar texto del campo E-mail
            var email = document.getElementById('id_email_2').value; 
            // Si el campo E-mail está vacio
            if (email == "") {
                error += '<font style="color:red">Debes escribir el E-mail</font>';
                document.getElementById('mensaje1').innerHTML = error;
                return;
            } 
            // Buscar texto del campo Mensaje
            var mensaje = document.getElementById('id_mensaje').value; 
            // Si el campo Mensaje está vacio
            if (mensaje == "") {
                error += '<font style="color:red">Debes escribir el Mensaje</font>';
                document.getElementById('mensaje1').innerHTML = error;
                return;
            } 
            // Jquery Ajax
            $.ajax({
                url: "codigo231.php",
                type: "POST",
                data: "email="+email+"&mensaje="+mensaje,
                success: function(resp){
                    $('#mensaje2').html(resp)
                }        
            });
        }
        function borrar_mensaje(){
            document.getElementById('mensaje1').innerHTML = "";
        }   
    </script>
</body>
</html>