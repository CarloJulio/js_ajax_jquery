<!-- 
Archivo: codigo188.php
-->
<?php
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario"])){
        echo "<a  href='codigo186.php'>Inicio</a><br/><br/>";
        echo "Usuario Cerrado";
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario"])){
        echo "<a  href='codigo186.php'>Inicio</a><br/><br/>";
        echo "Usuario Cerrado";
        exit();
    }
    // Iniciar variables se sesiones
    if (!isset($_SESSION["usuario_error"])){
        $_SESSION["usuario_error"] = "No";
    }
    if (!isset($_SESSION["usuario_error_mensaje"])){
        $_SESSION["usuario_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["usuario"])){
        $_SESSION["usuario"] = "";
    }
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
	<!-- Mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
    <a  href="#" onclick="cerrar_usuario()">Cerrar</a>
    <br/><br/>
	<!-- Fromulario -->    
    <form name="formulario_usuario" method="POST">
        <label>Autenticación Correcta</label>
        <br/>
        <label>Usuario: <?php echo $_SESSION["usuario"] ?></label>
    </form>
    <!-- Mensaje SweetAlert -->
    <?php
		$mensaje = $_SESSION["usuario_mensaje"];
        $usuario_mensaje = $_SESSION["usuario_mensaje_texto"];
        if ($mensaje=="Si") { // Si el campo esta vacío
            $_SESSION["usuario_mensaje"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $usuario_mensaje ?>',
                    html: '<span style="color:green"><?php echo $usuario_mensaje ?></span>',
                    timer: 3000,
                    confirmButtonText: 'Aceptar',
                    timerProgressBar:true,
                    allowOutsideClick: false
                });
            </script>
    <?php
        }
    ?>   
    <script>
    // Cerrar Sistema
    function cerrar_usuario() {
        Swal.fire({
            title: 'Mensaje',
            text: '¿Confirma en Cerrar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = 'codigo189.php';
            } else {
                // Dijeron que no
            }
        });
    }
    </script>
</body>
</html>