-- Archivo: codigo184.sql
INSERT INTO `usuarios` (`id`, `usuario`, `clave`) VALUES
(1, 'Juan', '12345');