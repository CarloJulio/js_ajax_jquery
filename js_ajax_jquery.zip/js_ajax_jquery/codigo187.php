<!-- 
Archivo: codigo187.php
-->
<?php
	// Iniciar sesión
	session_start();
	// Conexión a la base de datos 
	$servidor = "localhost";
	$db = "js_php_mysql";   
	$usuario = "root";
	$contrasenna = "mini2019";
	// Establece conexión base de datos
	$mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
	// Se presionó el botón abrir
	if (isset($_POST["usuario"])) {
		// Asignar el usuario a la variable de sesión
		$_SESSION["usuario"] = trim($_POST["usuario"]);
		$_SESSION["clave"] = trim($_POST["clave"]);
		// Chequear que el Usuario si existe
		$usuario = trim($_POST["usuario"]);
		$clave = trim($_POST["clave"]);
		// Sentencia sql
		$sql = "SELECT usuario, clave FROM usuarios WHERE (usuario = '$usuario') AND (clave = '$clave')";
		// Conexión a la tabla usuarios
		$query = $mysqli->query($sql);
		// Genera los registros
		$row_usuario = $query->fetch_assoc();
		// Cheque si la tabla usuarios tiene datos
		$nro_registros = $query->num_rows;
		// Si no hay datos en la tabla usuarios
		if($nro_registros==0) {
			// Asignar valores a las variables de sesiones
			$_SESSION["usuario_error"] = "Si";
			$_SESSION["usuario_error_mensaje"] = "Usuario o Clave Incorrecto";
			// Abrir archivo en php
			echo "<script>location.href = 'codigo186.php'</script>";
			// Salir de archivo actual
			exit();	
		}else{
	  		// Asignar valores a las variables de sesiones
			$_SESSION["usuario_mensaje"] = "Si";
			$_SESSION["usuario_mensaje_texto"] = "Bienvenido: ".$usuario;
			// Abrir archivo en php
			echo "<script>location.href = 'codigo188.php'</script>";
			// Salir de archivo actual
			exit();	
		} 
	} 
?>