<?php
  // Archivo: codigo247.php
	// Iniciar sesión del Usuario
  session_start();
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
  <!-- La etiqueta meta que da el formato en español -->
	<meta charset="utf-8">
  <!-- Mensajes Sweetalert -->
  <link href="css/sweetalert2.min.css" rel="stylesheet">
  <script src="js/sweetalert2.all.min.js"></script>
  <title> Ejercicio </title>
</head>
<body>
<div style="padding-left:10px; padding-top:10px">
		<a href="#" onclick="cerrar()">Cerrar</a>
		<br/>
		mensaje: <?php echo $_SESSION['mensaje']; ?>
</div>	
<?php
    // Mensaje de datos guardados 
    if($_SESSION["mensaje_recibido"] == "Si"){
        $_SESSION["mensaje_recibido"] = "No";
    ?>
    <script> 
        // Mensaje SweetAlert
        swal.fire({ title: 'Mensaje',
            text: 'Mensaje Recibido',
            html: '<span style="color:green">Mensaje Recibido</span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    </script>
<?php
    }
?>
<script>
  // Mensaje SweetAlert
  function cerrar() {
    Swal.fire({
      title: 'Mensaje',
      text: '¿Deseas Cerrar?',
      showCancelButton: true,
      confirmButtonText: 'Si',
      cancelButtonText: 'Cancelar',
      allowOutsideClick: false
    })
    .then(resultado => {
      if (resultado.value) {
        // Hicieron click en 'Sí'
        location.href = "codigo245.php";
      } else {
        // Hicieron click en 'Cancelar'
      }
    });
  }    
</script>
</body>
</html>