<!-- Archivo: codigo223.php --> 
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
    <!-- Códigos en javascript -->
    <script>
        // Función AJAX
        function mostrar(){
            // Compactible con diferentes navegadores
            var xmlhttp; 
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // Capa div para el AJAX
                    document.getElementById("id_datos").innerHTML=xmlhttp.responseText;
                }
            }
            // Abrir archivo con el número de la imagen y ejecutar el AJAX
            xmlhttp.open("GET","codigo224.php",true);
            xmlhttp.send();
        }
    </script>
</head>
<body>
    <h1> JSON con AJAX </h1>  
    <!-- Llama a la función AJAX desde un botón -->  
    <button onclick="mostrar()"><b>Mostrar Datos</b></button>
    <!-- Mensaje -->  
    <div id="id_datos"></div>
</body>
</html>