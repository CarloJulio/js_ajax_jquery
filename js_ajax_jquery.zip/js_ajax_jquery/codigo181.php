<!-- Archivo: codigo181.php -->
<!-- Documento HTML5 -->
<!DOCTYPE html>
<html>
<head>
   <!-- La etiqueta meta que da el formato en español -->
   <meta charset="UTF-8">
   <!-- Título en la pestaña del navegador -->
   <title> Ejercicio </title>
</head>
<body>
  <!-- Códigos de PHP -->
  <?php
  	$mensaje = "Hola Mundo";
  ?>
  <!-- Códigos de JavaScript -->
  <script>
    // Declarar e Inicializar variable con PHP
    var mensaje = "<?php echo $mensaje; ?>";
    // Mostrar mensaje
    alert(mensaje);
  </script>
</body>
</html>