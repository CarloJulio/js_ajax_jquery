-- Archivo: codigo213.sql
INSERT INTO `vehiculos_tipos` (`id_vehiculo_tipo`, `tipo`, `id_vehiculo`) VALUES
(1, 'Moto Particular', 1), (2, 'Moto Taxi', 1), (3, 'Carro', 2),
(4, 'Taxi', 2), (5, 'Camioneta', 2), (6, 'Buseta', 3), (7, 'Bus', 3),
(8, 'Camion 2 ejes', 4), (9, 'Camion 4 ejes', 4);