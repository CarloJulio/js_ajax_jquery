<!-- Archivo: Codigo232_jquery_ajax_validar_formulario.php --> 
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
    <!-- Librería jQuery -->
    <script src="js/jquery-1.10.1.min.js"></script>
</head>
<body>
    <h1>Usuario</h1>
    <form method="POST" action="return false" onsubmit="return false">
        <!-- Campo de texto Usuario -->  
        <label>Usuario</label>
        <br/>
        <input onclick="borrar_mensaje()" type="text" id="usuario" maxlength="20">
        <br/>  
        <!-- Campo de texto Clave -->  
        <label>Clave</label> 
        <br/>   
        <input onclick="borrar_mensaje()" type="password" id="clave" maxlength="20">
        <br/><br/>  
        <!-- Llama a la función en JavaScript desde un botón -->  
        <button onclick="validar();"><b>Ingresar</b></button>
        <br/>
        <div id="mensaje"></div>
    </form>
    <script>
        // Validar con JavaScript    
        function validar()
        {
            // Declarar e iniciar variable 
            var error="";
            // Buscar texto del campo usuario
            var usuario = document.getElementById('usuario').value; 
            // Si el campo Usuario está vacio
            if (usuario == "") {
                error += '<font style="color:red">Debes escribir el Usuario</font>';
                document.getElementById('mensaje').innerHTML = error;
                return;
            } 
            // Buscar texto del campo clave
            var clave = document.getElementById('clave').value; 
            // Si el campo Usuario está vacio
            if (clave == "") {
                error += '<font style="color:red">Debes escribir la Clave</font>';
                document.getElementById('mensaje').innerHTML = error;
                return;
            } 
            // Jquery Ajax
            $.ajax({
                url: "codigo233.php",
                type: "POST",
                data: "usuario="+usuario+"&clave="+clave,
                success: function(resp){
                    $('#mensaje').html(resp)
                }        
            });
        }
        function borrar_mensaje(){
            document.getElementById('mensaje').innerHTML = "";
        }   
    </script>
</body>
</html>