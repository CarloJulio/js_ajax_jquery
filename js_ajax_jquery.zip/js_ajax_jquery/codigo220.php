<?php
    // Archivo: codigo220.php 
	// Conexión a la base de datos
    $servidor = "localhost";
    $db = "js_php_mysql";   
    $usuario = "root";
    $contrasenna = "mini2019";
    // Establece conexión base de datos
	$mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
	// Datos del Usuario
    $usuario = $_GET['usuario'];
	$clave = $_GET['clave'];
    // Sentencia sql
	$sql = "SELECT usuario, clave FROM usuarios WHERE (usuario = '$usuario') AND (clave = '$clave')";
	// Conexión a la tabla usuarios
	$query = $mysqli->query($sql);
	// Genera los registros
	$row_usuario = $query->fetch_assoc();
	// Cheque si la tabla usuarios tiene datos
	$nro_registros = $query->num_rows;
	// Si no hay datos en la tabla usuarios
	if($nro_registros==0) {
		echo "<h1>Usuario</h1>";  
        echo "<label>Usuario</label>";
		echo "<br/>";
		echo "<input onclick='borrar_mensaje()' type='text' id='usuario' maxlength='20' value=".$usuario.">";
		echo "<br/>"; 
		echo "<label>Clave</label>"; 
		echo "<br/>";    
		echo "<input onclick='borrar_mensaje()' type='password' id='clave' maxlength='20' value=".$clave.">";
		echo "<br/><br/>";
		echo "<button onclick='validar()'><b>Ingresar</b></button>";
		// Mensaje de Usuario no existe
		echo "<div id='id_mensaje'><font style='color:red'>Usuario o Clave incorrecta</font></div>";
		$_SESSION['usuario_existe'] = "No";
	}else{
		echo "<a  href='codigo219.php'>Cerrar</a>";
    	echo "<br/><br/>";
		// Mensaje de autenticación correcta
		echo "<form name='formulario_usuario' method='POST'>";
        echo "<label>Autenticación Correcta</label>";
        echo "<br/>";
        echo "<label>Usuario:".$usuario."</label>";
		echo "</form>";
	} 
?>