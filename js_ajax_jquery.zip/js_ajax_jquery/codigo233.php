<?php
// Archivo: Codigo233_jquery_ajax_validar_formulario.php
// Validar Con PHP
// Iniciar Sesión
session_start();
// Conexión a la base de datos
$servidor = "localhost";
$usuario = "root";
$contrasenna = "mini2019";
$db = "js_php_mysql";  
$mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
// Datos del Usuario
$usuario = $_POST['usuario'];
$clave = $_POST['clave'];
// Sentencia sql
$sql = "SELECT usuario, clave FROM usuarios WHERE (usuario = '$usuario') AND (clave = '$clave')";
// Conexión a la tabla usuarios
$query = $mysqli->query($sql);
// Genera los registros
$row_usuario = $query->fetch_assoc();
// Chequea si la tabla usuarios está el Usuario
$nro_registros = $query->num_rows;
// Si no está el Usuario en la tabla usuarios
if($nro_registros!=0) {
    // Asiganr valor a la variable de sesión
    $_SESSION["usuario"] = $usuario;
    echo '<script>location.href = "codigo234.php"</script>';
   
}else {
    echo "<font style='color:red'>Usuario o Clave incorrecta</font>";
}
?>