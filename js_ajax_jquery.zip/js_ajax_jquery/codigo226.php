<?php
    //  Archivo: codigo226.php
    // Conexión a la base de datos
    $servidor = "localhost";
    $db = "js_php_mysql";   
    $usuario = "root";
    $contrasenna = "mini2019";
    $mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
    // Lista Vehiculos
    $sqlpa="SELECT id_vehiculo, vehiculo FROM vehiculos ORDER BY id_vehiculo";
    $querypa = $mysqli->query($sqlpa);
    $combobit1="<option value='0'>Seleccione</option>";
    while ($rowpa=$querypa->fetch_assoc()) { 
        $combobit1.=" <option value='".$rowpa['id_vehiculo']."'>".$rowpa['vehiculo']."</option>"; 
    }
    // Lista Vehiculo Tipos
    $combobit2="<option value='0'>Seleccione</option>";
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title>Vehículos</title>
    <!-- Librería jQuery -->
    <script src="js/jquery-1.10.1.min.js"></script>
</head>
<body>
    <div>
      <h3>Vehículos</h3>    
      <form>
        <label><b>Vehículo</b></label><br/>
        <select id="id_vehiculo"><?php echo $combobit1;?></select>
        <br/><br/>
        <label><b>Vehículo Tipo</b></label>
        <div id="id_vehiculo_tipo">
            <select><?php echo $combobit2;?></select>
        </div>
      </form>
    </div>
    <script>
        // Función jQuery
        $(document).ready(function(){
            $('#id_vehiculo').on('change',function(){
                var id_vehiculo = $(this).val();
                $.ajax({
                    type:'POST',
                    url:'codigo227.php',
                    data:'id_vehiculo='+id_vehiculo,
                    success:function(html){
                        $('#id_vehiculo_tipo').html(html);
                    }
                })
            })    
        })
    </script>
</body>
</html>