-- Archivo: codigo211.sql
INSERT INTO `vehiculos` (`id_vehiculo`, `vehiculo`) VALUES
(1, 'Motos'), (2, 'Carros'), (3, 'Buses'), (4, 'Camiones');