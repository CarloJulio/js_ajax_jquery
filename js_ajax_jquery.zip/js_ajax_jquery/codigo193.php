<!-- 
Archivo: codigo193.php
-->
<?php
    if (isset($_GET["texto"])) {
        $texto=$_GET["texto"];
    }
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
</head>
<body>
    <a  href="codigo192.html">Volver</a>
    <br/>
    <!-- Mostrar texto -->    
    <p>Escribiste el texto:<?php echo $texto ?></p>
    </form>
</body>
</html>