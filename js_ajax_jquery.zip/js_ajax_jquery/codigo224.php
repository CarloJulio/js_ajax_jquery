<?php
    // Archivo: codigo224.php
	// Conexión a la base de datos
    $servidor = "localhost";
    $db = "js_php_mysql";   
    $usuario = "root";
    $contrasenna = "mini2019";
    // Establece conexión base de datos
	$mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
	// Sentencia sql
	$sql = "SELECT id_cliente, nombre, email, telefono FROM clientes";
	// Conexión a la tabla usuarios
	$query = $mysqli->query($sql);
	// Cheque si la tabla clientes tiene datos
	$nro_registros = $query->num_rows;
	// Si  hay datos en la tabla clientes
	if($nro_registros!=0) {
		// Se crae un array
		$clientes = array(); 
		// Genera los registros
		while($row = mysqli_fetch_array($query)) 
		{ 
			$id=$row['id_cliente'];
			$nombre=$row['nombre'];
			$email=$row['email'];
			$telefono=$row['telefono'];
			// Llenando el array
			$clientes[] = array('id'=> $id, 'nombre'=> $nombre, 'email'=> $email, 'telefono'=> $telefono);
		}
		//desconectar la base de datos
		$close = mysqli_close($mysqli) 
		or die("Ha sucedido un error inexperado en la desconexion de la base de datos");
		// variable JSON
		$json_string = json_encode($clientes);
		echo "<br/>";
		echo $json_string;
	}else{
		echo "<label>No se encontró datos</label>";
    } 
?>