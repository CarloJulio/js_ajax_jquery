-- Archivo: codigo210.sql
CREATE TABLE `vehiculos` (
  `id_vehiculo` int(1) NOT NULL AUTO_INCREMENT,
  `vehiculo` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_vehiculo`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;