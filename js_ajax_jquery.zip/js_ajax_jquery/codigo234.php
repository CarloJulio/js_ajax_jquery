<?php
// Archivo: Codigo234_jquery_ajax_validar_formulario.php
// Iniciar Sesión
session_start();
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
    <link rel="stylesheet" href="estilo.css" />
</head>
<body>
    <a href="codigo235.php">Cerrar Sesión</a>
    <p>BIENVENIDO : <?php echo $_SESSION['usuario']; ?></p>
</body>
</html>