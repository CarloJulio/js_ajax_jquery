<?php
    // Archivo: codigo218.php
    // Conexión a la base de datos Alquileres Antonella
	$servidor = "localhost";
	$db = "js_php_mysql";   
	$usuario = "root";
	$contrasenna = "mini2019";
	// Establece conexión base de datos
	$mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
    // Los valores del input email y el input mensaje
    $email = $_GET['email'];
    $mensaje = $_GET['mensaje'];
    // Guardar nuevo mensaje	
	$sql="INSERT INTO mensajes (email, mensaje) ";
	$sql.="VALUES ('$email','$mensaje')";
    $query=$mysqli->query($sql);
    // Capa div id_email_1 para el AJAX, introduce el mensaje
    echo '<font style="color:green">Mensaje enviado con éxito</font>';
?>