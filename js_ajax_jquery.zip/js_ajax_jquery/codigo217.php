<!-- Archivo: codigo217.php -->
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
    <script>
        // Función AJAX
        function enviar(){
            // Valor del input id_email
            var email = document.getElementById("id_email_2").value;
            // Si el campo está vacio
            if (email == "") {
                document.getElementById("id_mensaje_error").innerHTML = '<font style="color:red">Debes escribir el Email</font>';
                return;
            };
            // Valor del input id_mensaje
            var mensaje = document.getElementById("id_mensaje").value;
            // Si el campo está vacio
            if (mensaje == "") {
                document.getElementById("id_mensaje_error").innerHTML = '<font style="color:red">Debes escribir el Mensaje</font>';
                return;
            };
            // Compactible con diferentes navegadores
            var xmlhttp; 
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // Capa div para el AJAX
                    document.getElementById("id_email_1").innerHTML=xmlhttp.responseText;
                }
            }
            // Abrir archivo con el número de la imagen y ejecutar el AJAX
            xmlhttp.open("GET","codigo218.php?email="+email+"&mensaje="+mensaje,true);
            xmlhttp.send();
        }
    </script>
</head>
<body>
    <h1>Mensaje (Ajax)</h1>  
    <div id="id_email_1">
        <label>Email</label>
        <br/>
        <!-- Campo de texto Email -->   
        <input type="text" onclick="borrar_mensaje_error()" id="id_email_2" maxlength="30">
        <br/>
        <label>Mensaje</label>
        <br/>
        <!-- Campo de texto Mensaje -->   
        <Textarea ROWS="3" COLS="30"type="text" onclick="borrar_mensaje_error()" id="id_mensaje" maxlength="150"></TEXTAREA>
        <br/>
        <!-- Llama a la función AJAX desde un botón -->  
        <button onclick="enviar()"><b>Enviar</b></button>
        <!-- Mensaje error -->  
        <div id="id_mensaje_error"></div>
    </div> 
    <script>
        // Borrar mensaje en div id_mensaje_error
        function borrar_mensaje_error(){
            document.getElementById("id_mensaje_error").innerHTML = '';      
        }   
    </script>    
</body>
</html>