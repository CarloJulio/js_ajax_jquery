<?php 
	// Archivo: codigo238.php
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario"])){
        echo "<a  href='codigo236.php'>Inicio</a><br/><br/>";
        echo "Usuario Cerrado";
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario"])){
        echo "<a  href='codigo236.php'>Inicio</a><br/><br/>";
        echo "Usuario Cerrado";
        exit();
    }
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html>
<head>
	<!-- La etiqueta meta que da el formato en español -->
	<meta charset="utf-8">
	<!-- jQuery Alert -->
	<link rel="stylesheet" href="demo/libs/bundled.css">
	<script src="demo/libs/bundled.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery-confirm.css"/>
	<script type="text/javascript" src="js/jquery-confirm.js"></script>
	<title> Ejercicio </title>
</head>
<body>
	<div style="padding-left:10px; padding-top:10px">
		<a href="#" onclick="cerrar();">Cerrar</a>
		<br/>
		Usuario: <?php echo $_SESSION['usuario']; ?>
	</div>	
	<?php 
		// Mensaje de bienvenida
		if ($_SESSION['usuario_bienvenido'] == "si") {
			$_SESSION['usuario_bienvenido'] = "no";
			echo "<script>
				$.confirm({
			  		title: 'Mensaje',
			  		content: '<span style=color:green>Bienvenido</span>',
			  		autoClose: 'Cerrar|3000',
			  		buttons: {
				  		Cerrar: function () {
				  	}}
			  	});
			</script>";
   	    }
	?>	
	<script>
	function cerrar() {
		// Mensaje de confirmación
		$.confirm({
			title: 'Mensaje',
			content: '¿Deseas Cerrar Usuario?',
			animation: 'scale',
			closeAnimation: 'zoom',
			buttons: {
    			confirm: {
        			text: 'Si',
        			btnClass: 'btn-orange',
           			action: function(){
	        			location.href="codigo239.php";				     
           			} // action: function(){
    			}, // confirm: {
    			cancelar: function(){
    		}// cancelar: function()
		} // buttons
		}); // $.confirm
	}
</script>
</body>
</html>