<?php
    // Archivo: codigo208.php
    // Número aleatorio del 1 al 31
    $nro=rand(1,31);
    // Nombre de la imagen
    $imagen = $nro.".jpg";
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
     <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
    <script>
        // Función AJAX
        function otra_imagen(){
            // Número aleatorio
            var nro_imagen = Math.random()*31;
            // Nombre de la imagen
            nro_imagen = Math.round(nro_imagen); 
            if(nro_imagen == 0) {
                nro_imagen = 1;                
            }
            // Compactible con diferentes navegadores
            var xmlhttp; 
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // Capa div para el AJAX
                    document.getElementById("id_imagen").innerHTML=xmlhttp.responseText;
                }
            }
            // Abrir archivo con el número de la imagen y ejecutar el AJAX
            xmlhttp.open("GET","codigo209.php?nro_imagen="+nro_imagen,true);
            xmlhttp.send();
        }
    </script>
</head>
<body>
    <h1>Gatitos</h1>  
    <div>
        <!-- Introducir una table con registros y columnas -->  
        <table>  
            <tr>
                <td> 
                    <!-- Llama a la función AJAX desde un botón -->  
                    <button onclick="otra_imagen()" class="boton" name="boton_imagen"><p style="font-size:20px;"><b>Cambiar</b></p></button>
                </td>     
            </tr>  
            <tr>
                <td> 
                    <br/>
                </td>     
            </tr>
            <tr>
                <td> 
                    <!-- Muestra la imagen -->  
                    <div id="id_imagen">
                        <img src="imagenes/gatos/<?php echo $imagen ?>" width="40%" height="40%" />       
                    </div>
                </td>  
            </tr>
        </table>
    </div> 
</body>
</html>