<?php
    // Archivo: codigo237.php
    // Iniciar sesión del Usuario
    session_start();
    // Iniciar variable de sesión
    $_SESSION['usuario_bienvenido'] = "no";
    // Conexión a la base de datos  
    $servidor = "localhost";
    $db = "js_php_mysql";   
    $usuario = "root";
    $contrasenna = "mini2019";
    // Establece conexión base de datos
    $mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
    // Datos del Usuario
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];
    // Variable de sesiones
    $_SESSION['usuario_2'] = $_POST['usuario'];
    $_SESSION['clave_2'] = $_POST['clave'];
    $_SESSION["usuario"] = $usuario;
    // Sentencia sql
    $sql = "SELECT usuario, clave FROM usuarios WHERE (usuario = '$usuario') AND (clave = '$clave')";
    // Conexión a la tabla usuarios
    $query = $mysqli->query($sql);
    // Genera los registros
    $row_usuario = $query->fetch_assoc();
    // Cheque si la tabla usuarios tiene datos
    $nro_registros = $query->num_rows;
    // Si existe el usuario
    if($nro_registros!=0) {
        $_SESSION['usuario_bienvenido'] = "si";
        echo '<script>location.href = "codigo238.php"</script>';
    } 
    else
    {
        $_SESSION['usuario_valido'] = 'no';
        echo "<script>location.href = 'codigo236.php'</script>";
    }
?>