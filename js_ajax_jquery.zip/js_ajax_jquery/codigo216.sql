-- Archivo: Codigo216_Crear_Tabla_Mensajes
CREATE TABLE `mensajes` (
  `id_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) CHARACTER SET utf8 NOT NULL,
  `mensaje` varchar(150) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_mensaje`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;