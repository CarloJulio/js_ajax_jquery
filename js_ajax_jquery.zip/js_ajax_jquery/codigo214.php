<?php
    // Archivo: codigo210.php
    // Conexión a la base de datos
	$servidor = "localhost";
	$db = "js_php_mysql";   
	$usuario = "root";
	$contrasenna = "mini2019";
    $mysqli = new mysqli($servidor, $usuario, $contrasenna, $db);
    // Lista Vehiculos
    $sqlpa="SELECT id_vehiculo, vehiculo FROM vehiculos ORDER BY id_vehiculo";
    $querypa = $mysqli->query($sqlpa);
    $combobit1="<option value='0'>Seleccione</option>";
    while ($rowpa=$querypa->fetch_assoc()) { 
        $combobit1.=" <option value='".$rowpa['id_vehiculo']."'>".$rowpa['vehiculo']."</option>"; 
    }
    // Lista Vehiculo Tipos
    $combobit2="<option value='0'>Seleccione</option>";
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la pestaña del navegador -->
	<title>Vehículos</title>
    <script>
        // Función AJAX se activa con el evento onchange
        function showselect(str){
            var xmlhttp; 
            if (window.XMLHttpRequest)
            {// código para IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp=new XMLHttpRequest();
            }
            else
            {// Código para IE6, IE5
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    document.getElementById("id_vehiculo_tipo").innerHTML=xmlhttp.responseText;
                }
            }
            xmlhttp.open("GET","codigo215.php?c="+str,true);
            xmlhttp.send();
        }
    </script>
</head>
<body>
	<div>
	  <h3>Vehículos</h3>	
	  <form>
        <label><b>Vehículo</b></label><br/>
        <select onchange="showselect(this.value)"><?php echo $combobit1;?></select>
        <br/><br/>
        <label><b>Vehículo Tipo</b></label>
        <div id="id_vehiculo_tipo">
            <select><?php echo $combobit2;?></select>
        </div>
      </form>
    </div>
</body>
</html>