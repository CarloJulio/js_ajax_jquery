<!-- 
Archivo: codigo199.php
-->
<?php
    if (isset($_GET["nombre"])) {
        $texto=$_GET["nombre"];
    }
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
</head>
<body>
    <a  href="codigo198.html">Volver</a>
    <br/>
    <!-- Mostrar texto -->    
    <p>Escribiste el nombre:<?php echo $texto ?></p>
    </form>
</body>
</html>