<?php
	// Archivo: codigo236.php
	// Iniciar sesión del Usuario
	session_start();
	// Si las varibles de sesión no está definida
	if(!isset($_SESSION['usuario_2'])) {
		$_SESSION['usuario_2']="";
		$_SESSION['clave_2']="";
	}	
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
	<!-- La etiqueta meta que da el formato en español -->
	<meta charset="UTF-8">
	<!-- jQuery Alert -->
	<link rel="stylesheet" href="demo/libs/bundled.css">
	<script src="demo/libs/bundled.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery-confirm.css"/>
	<script type="text/javascript" src="js/jquery-confirm.js"></script>
	<title> Ejercicio </title>
</head>
<body>
	<div style="padding-left:10px">
		<h3>Iniciar Usuario</h3>
		<form action="return false" onsubmit="return false" method="POST">
			<label>Usuario:</label>
			<br/>
			<input type="text" id="usuario" name="usuario" autofocus value=<?php echo $_SESSION['usuario_2']; ?>>
			<br/>
			<label>Clave:</label>
			<br/>
			<input type="password" id="clave" name="clave" value=<?php echo $_SESSION['clave_2']; ?>>
			<br/><br/>
    		<input onclick="validar()" type="submit" id="btn-submit" value="Ingresar">
		</form>
		<div id="mensaje1" class="mensaje1"></div>
	</div>
	<script>
	   	function validar()
    	{
			var usuario = document.getElementById('usuario').value;
			var clave  = document.getElementById('clave').value;
    		if(usuario==""){
    			$.alert({
               		title: 'Mensaje',
               		content: '<span style=color:red>Debes escribir el Usuario.</span>',
               		animation: 'scale',
               		closeAnimation: 'scale',
               		buttons: {
                   		okay: {
                       		text: 'Cerrar',
                       		btnClass: 'btn-warning'
                   		}
               		}
           		});
    			return 0;
    		} 
    		if(clave==""){
    			$.alert({
               		title: 'Mensaje',
               		content: '<span style=color:red>Debes escribir la Clave.</span>',
               		animation: 'scale',
               		closeAnimation: 'scale',
               		buttons: {
                   		okay: {
                       		text: 'Cerrar',
                       		btnClass: 'btn-warning'
                   		}
               		}
       			});
                return 0;
    		} 
			$.ajax({
				url: "codigo237.php",
				type: "POST",
				data: "usuario="+usuario+"&clave="+clave,
        		success: function(resp){
           			$('#mensaje1').html(resp)
        		}        

        	});
      	}
    </script>
	<?php 
		if ( isset($_SESSION['usuario_valido']) && $_SESSION['usuario_valido'] == "no" ) {
			unset($_SESSION['usuario_valido']);
   			echo "<script>
				$.alert({
                    title: 'Mensaje',
                    content: '<span style=color:red>El usuario o la clave son incorrectas.</span>',
                    animation: 'scale',
                    closeAnimation: 'scale',
                    buttons: {
                        okay: {
                            text: 'Cerrar',
                            btnClass: 'btn-warning'
                        }
                    }
                });
    		</script>";
   	    }
	?>
</body>
</html>