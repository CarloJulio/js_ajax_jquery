<?php
	// Archivo: codigo242.php
	// Iniciar sesión del mensaje
	session_start();
	// Si la varible de sesión no está definida
	if(!isset($_SESSION['mensaje'])) {
		$_SESSION['mensaje']="";
	}	
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>
	<!-- La etiqueta meta que da el formato en español -->
	<meta charset="UTF-8">
	<!-- jQuery Alert -->
	<link rel="stylesheet" href="demo/libs/bundled.css">
	<script src="demo/libs/bundled.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery-confirm.css"/>
	<script type="text/javascript" src="js/jquery-confirm.js"></script>
	<title> Ejercicio </title>
</head>
<body>
	<div style="padding-left:10px">
		<h3>jQuery-Alert</h3>
		<!-- Formulario HTML -->
		<form action="return false" onsubmit="return false" method="POST">
			<label>Mensaje:</label>
			<br/>
			<input type="text" id="mensaje" name="mensaje" autofocus value=<?php echo $_SESSION['mensaje']; ?>>
			<br/><br/>
			<input onclick="validar()" type="submit" id="btn-submit" value="Enviar">
		</form>
		<div id="mensaje1" class="mensaje1"></div>
	</div>
	<script>
	   	function validar()
    	{
			var mensaje = document.getElementById('mensaje').value
    		// Mensaje si el campo mensaje si está vacio
			if(mensaje==""){
    			$.alert({
               		title: 'Mensaje',
               		content: '<span style=color:red>Debes escribir un Mensaje.</span>',
               		animation: 'scale',
               		closeAnimation: 'scale',
               		buttons: {
                   		okay: {
                       		text: 'Cerrar',
                       		btnClass: 'btn-warning'
                   		}
               		}
           		});
    			return 0;
    		} 
			// Mensaje de confirmación
			$.confirm({
				title: 'Mensaje',
				content: '¿Deseas Enviar?',
				animation: 'scale',
				closeAnimation: 'zoom',
				buttons: {
    				confirm: {
        				text: 'Si',
        				btnClass: 'btn-orange',
           				action: function(){
	        				$.ajax({
								url: "codigo243.php",
								type: "POST",
								data: "mensaje="+mensaje,
        						success: function(resp){
           							$('#mensaje1').html(resp)
        						}        
        					});
           				} // action: function(){
    				}, // confirm: {
    				cancelar: function(){
    				}// cancelar: function()
				} // buttons
			}); // $.confirm
      	}
    </script>
</body>
</html>