<!-- 
Archivo: codigo229.php
-->
<?php
    // Si está definida la variable $_GET["fecha"]
    if (isset($_POST["fecha"])) {
        // Asignar fecha a la variable 
        $fecha = $_POST["fecha"];
    }
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
	<meta charset="UTF-8">
</head>
<body>
    <a  href="codigo228.php">Volver</a>
    <br/>
    <!-- Mostrar fecha -->    
    <p>Fecha:<?php echo $fecha ?></p>
    </form>
</body>
</html>