<?php
    // Archivo: codigo239.php
    // Iniciar sesión del Usuario
    session_start();
    // Borrar las variables de sesiones
    session_destroy();
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html lang="es">
<head>  
    <!-- La etiqueta meta que da el formato en español -->
	<meta charset="UTF-8">
</head>
<body>
    <a href="codigo236.php">Inicio</a>
    <p>Usuario Cerrado</p>
</body>
</html>