<?php
    // Archivo: codigo243.php
    // Iniciar sesión del Usuario
    session_start();
    // Iniciar variable de sesión 
    $_SESSION['mensaje_recibido'] = "si";
    $_SESSION["mensaje"] = $_POST['mensaje'];
    // Abre un archivo
    echo '<script>location.href = "codigo244.php"</script>';
?>