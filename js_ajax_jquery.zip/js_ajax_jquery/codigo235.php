<?php
// Archivo: Codigo235_jquery_ajax_validar_formulario.php
// Iniciar Sesión
session_start();
// Cerrar Sesión
session_destroy();
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato en español -->
<html lang="es">
<head>
    <!-- La etiqueta meta que da el formato en español -->
    <meta charset="UTF-8">
    <!-- Título de la pestaña del navegador -->
    <title> Ejercicio </title>
</head>
<body>
    <a href="codigo232.php">Ir a la Pagina Iniciar Sesión</a>
    <p>Ha terminado la sesión</p>
</body>
</html>