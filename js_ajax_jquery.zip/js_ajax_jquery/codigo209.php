<?php
	// Archivo: codigo209.php
	$nro_imagen = $_GET['nro_imagen'];
	$imagen = $nro_imagen.".jpg";
	// Capa div id_imagen para el AJAX, introduce la imagen
    echo "<img src='imagenes/gatos/$imagen' width='40%' height='40%' />";
?>