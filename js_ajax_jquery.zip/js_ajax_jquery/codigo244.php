<?php 
	// Archivo: codigo244.php
	// Iniciar sesión 
	session_start();
	// Asignar valor a la variable
	$mensaje = $_SESSION['mensaje'];
?>
<!-- Documento HTML5 -->
<!DOCTYPE html>
<!-- Formato español -->
<html>
<head>
	<!-- La etiqueta meta que da el formato en español -->
	<meta charset="utf-8">
	<!-- jQuery Alert -->
	<link rel="stylesheet" href="demo/libs/bundled.css">
	<script src="demo/libs/bundled.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery-confirm.css"/>
	<script type="text/javascript" src="js/jquery-confirm.js"></script>
	<title> Ejercicio </title>
</head>
<body>
	<div style="padding-left:10px; padding-top:10px">
		<a href="#" onclick="cerrar();">Cerrar</a>
		<br/>
		mensaje: <?php echo $mensaje; ?>
	</div>	
	<?php 
		// Mensaje de bienvenida
		if ($_SESSION['mensaje_recibido'] == "si") {
			$_SESSION['mensaje_recibido'] = "no";
			echo "<script>
				$.confirm({
			  		title: 'Mensaje',
			  		content: '<span style=color:green>Mensaje Recibido</span>',
			  		autoClose: 'Cerrar|3000',
			  		buttons: {
				  		Cerrar: function () {
				  	}}
			  	});
			</script>";
   	    }
	?>	
	<script>
	function cerrar() {
		// Mensaje de confirmación
		$.confirm({
			title: 'Mensaje',
			content: '¿Deseas Cerrar?',
			animation: 'scale',
			closeAnimation: 'zoom',
			buttons: {
    			confirm: {
        			text: 'Si',
        			btnClass: 'btn-orange',
           			action: function(){
	        			location.href="codigo242.php";				     
           			} // action: function(){
    			}, // confirm: {
    			cancelar: function(){
    		}// cancelar: function()
		} // buttons
		}); // $.confirm
	}
</script>
</body>
</html>